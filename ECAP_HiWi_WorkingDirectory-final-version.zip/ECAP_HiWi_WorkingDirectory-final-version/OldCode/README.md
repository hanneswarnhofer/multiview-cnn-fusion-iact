# ECAP_HiWi_WorkingDirectory

A summary of the code pieces for CNN event classification with H.E.S.S. data
