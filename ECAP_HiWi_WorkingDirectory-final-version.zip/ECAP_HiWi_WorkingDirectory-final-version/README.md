[output-figure_singleviewCNN.pdf](https://github.com/hanneswarnhofer/ECAP_HiWi_WorkingDirectory/files/14331626/output-figure_singleviewCNN.pdf)
